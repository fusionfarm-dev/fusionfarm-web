<?php
// Fusion Farm contact form: shared helpers (ported from PR #1, codex/intelligence-rebuild).
// Real credentials live OUTSIDE the web root, one level above it:
//   /home/USER/fusionfarm-contact-config.php   (web root: /home/USER/fusionfarm.net)
// See tools/contact-config.example.php. This file is not reachable over HTTP (.htaccess).
declare(strict_types=1);

const FF_ROUTES = [
    'project'  => ['research', 'Projects, research & engagements'],
    'research' => ['research', 'Research'],
    'domains'  => ['domains',  'Digital assets'],
    'support'  => ['support',  'Support'],
];

function ff_config(): array {
    $file = dirname(__DIR__, 2) . '/fusionfarm-contact-config.php';
    if (!is_file($file)) return [];
    $config = require $file;
    return is_array($config) ? $config : [];
}

function ff_ready(array $config): bool {
    return !empty($config['enabled']) && !empty($config['site_key']) && !empty($config['secret_key'])
        && !empty($config['hostname']) && !empty($config['from_email'])
        && filter_var($config['from_email'], FILTER_VALIDATE_EMAIL) !== false
        && str_ends_with($config['from_email'], '@fusionfarm.net');
}

function ff_json(int $status, array $data): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function ff_value(array $data, string $key, int $max, bool $required = false): string {
    if (!isset($data[$key])) $data[$key] = '';
    if (!is_string($data[$key])) throw new InvalidArgumentException('Please check the form fields.');
    $value = trim($data[$key]);
    if (strlen($value) > $max || ($required && $value === '')) throw new InvalidArgumentException('Please check the form fields.');
    return $value;
}

function ff_message(array $data): array {
    $name = ff_value($data, 'name', 120, true);
    $company = ff_value($data, 'company', 160);
    $email = ff_value($data, 'email', 254, true);
    $topic = ff_value($data, 'topic', 30, true);
    $message = ff_value($data, 'message', 5000, true);
    if (!isset(FF_ROUTES[$topic]) || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || preg_match('/[\r\n\x00]/', $email . $name . $company) || strlen($message) < 10) {
        throw new InvalidArgumentException('Please check your email, topic and message.');
    }
    [$box, $label] = FF_ROUTES[$topic];
    return [
        'to' => $box . '@fusionfarm.net',
        'reply_to' => $email,
        'subject' => 'Website inquiry: ' . $label . ($company !== '' ? " ($company)" : ''),
        'body' => "Topic:   $label\nName:    $name\nCompany: " . ($company !== '' ? $company : '-') . "\nEmail:   $email\n\n"
            . "What decision are you trying to make?\n$message\n\n-- sent from fusionfarm.net/contact",
    ];
}
